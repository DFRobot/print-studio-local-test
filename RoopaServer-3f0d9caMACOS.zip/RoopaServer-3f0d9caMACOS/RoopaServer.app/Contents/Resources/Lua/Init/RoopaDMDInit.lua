local function readResourceFiles( msg )
    msg.loader.addCatalog( "RoopaDMD" )
    require( "RoopaDMD/ValidateDB" )
    require( "RoopaDMD/Units" )
end

do
    local bc = akSupport.ci( akSupport.Broadcaster )
    local msg = akRES.ReadResourceFilesMsg
    local signal = bc.getSignalWithPriority( "DataModelDefn", "App", msg )
    signal.onBroadcast = readResourceFiles
end
