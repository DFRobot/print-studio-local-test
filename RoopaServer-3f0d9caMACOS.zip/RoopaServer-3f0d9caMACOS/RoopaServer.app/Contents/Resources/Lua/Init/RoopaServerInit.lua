local function readResourceFiles( msg )
    local loader = msg.loader
    loader.addCatalog( "RoopaServer" )
    require( "RoopaServer/API" )
end

do
    local bc = akSupport.ci( akSupport.Broadcaster )
    local msg = akRES.ReadResourceFilesMsg
    local signal = bc.getSignalWithPriority( "Server", "App", msg )
    signal.onBroadcast = readResourceFiles
end
