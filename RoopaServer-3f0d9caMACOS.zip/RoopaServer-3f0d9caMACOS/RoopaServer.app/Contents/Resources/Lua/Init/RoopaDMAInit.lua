local function readResourceFiles( msg )
    msg.loader.addCatalog( "RoopaDMA" )
end

do
    local bc = akSupport.ci( akSupport.Broadcaster )
    local msg = akRES.ReadResourceFilesMsg
    local signal = bc.getSignalWithPriority( "DataModelDefn", "App", msg )
    signal.onBroadcast = readResourceFiles
end
